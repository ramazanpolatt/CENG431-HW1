package com.company.Application;

public interface IProduct {

    public String getID();
    public String toString();
}
